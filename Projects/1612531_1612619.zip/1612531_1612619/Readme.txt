Do dung lượng lớn hơn 20MB, nhóm chúng em xin phép nộp sưu liệu cuối kì qua link Google Drive:
https://drive.google.com/drive/folders/1PrS1odlfq8BRFh6OPN_GHcb7Nz3aem46?usp=sharing